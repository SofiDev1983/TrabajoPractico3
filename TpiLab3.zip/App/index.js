import { App as AdminApp } from "./App.js";

document.addEventListener("DOMContentLoaded", AdminApp);
window.addEventListener("hashchange", AdminApp);
