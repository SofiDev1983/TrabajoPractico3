class Categoria {
  constructor(id, descripcion) {
    this.id = id;
    this.descripcion = descripcion;
  }
}
